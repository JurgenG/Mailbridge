DROP TABLE IF EXISTS `#__mailbridge_parameters`;
DROP TABLE IF EXISTS `#__mailbridge_config`;